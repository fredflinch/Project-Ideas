# Project Ideas

Add text to cat image (on a sign) <br/>
-App or webapp<br/><br/>

Security camera <br/>
-Machine learning to detect people in the shot.<br/>
-Live camera feed on web browser/maybe app<br/><br/>

Musical Instrument <br/>
-Mapping sounds to different frequencies to make an instrument<br/><br/>

Frequency modulation synthesis engine <br/>
Chowning paper on FM synth https://web.eecs.umich.edu/~fessler/course/100/misc/chowning-73-tso.pdf<br/>

Low Compute Cost optimisation ML algo for embeded or low power compute systems 

