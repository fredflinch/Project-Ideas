document.body.onload = function(){
alert("test")
}
